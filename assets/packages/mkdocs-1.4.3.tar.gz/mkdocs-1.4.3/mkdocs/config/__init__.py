from mkdocs.config.base import Config, load_config

__all__ = ['load_config', 'Config']
