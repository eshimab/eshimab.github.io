# Test sub pages and referencing images

## Reference an image in: /

### Relative path

    ![Image](image.png)

![Image](image.png)


### Relative path 2

    ![Image](./image.png)

![Image](./image.png)


### Absolute path

    ![Image](/image.png)

![Image](/image.png)
