#!/usr/bin/env python


# For acceptable version formats, see https://www.python.org/dev/peps/pep-0440/
__version__ = '1.4.3'
